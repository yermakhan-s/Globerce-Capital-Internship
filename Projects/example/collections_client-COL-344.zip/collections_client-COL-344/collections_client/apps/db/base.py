from collections_client.apps.db.base_model import Model  # noqa
from collections_client.apps.collections_core.models import * # noqa
