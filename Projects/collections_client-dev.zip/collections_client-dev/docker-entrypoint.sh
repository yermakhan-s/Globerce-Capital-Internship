#!/bin/sh

python receive.py